package com.you.duressguard;

import android.content.SharedPreferences;

import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Runs inside system_server. Hooks the credential-check path of
 * LockSettingsService so we can see every typed lock-screen PIN/password.
 *
 * If the typed credential matches the stored duress-PIN hash, we act on the
 * configured app list (uninstall or hide) and then let the real check
 * continue untouched - so the lock screen still just shows "wrong PIN" and
 * nothing about the device looks different.
 *
 * Matches against your REAL pin, or any OTHER wrong pin, do nothing here.
 */
public class Hook implements IXposedHookLoadPackage {

    private static final String TAG = "DuressGuard";
    private static final String OWN_PACKAGE = "com.you.duressguard";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        // system_server shows up as package "android" to classic Xposed modules.
        if (!"android".equals(lpparam.packageName)) {
            return;
        }

        try {
            Class<?> lockSettingsServiceClass = XposedHelpers.findClass(
                    "com.android.server.locksettings.LockSettingsService",
                    lpparam.classLoader);

            XC_MethodHook callback = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    try {
                        handleCredentialCheck(param);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + ": error while checking credential: " + t);
                    }
                }
            };

            // Covers checkCredential / verifyCredential overloads across
            // Android versions; harmless no-op if a given overload isn't
            // present on this build.
            safeHookAll(lockSettingsServiceClass, "checkCredential", callback);
            safeHookAll(lockSettingsServiceClass, "verifyCredential", callback);

            XposedBridge.log(TAG + ": hooks installed into LockSettingsService");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": failed to install hooks: " + t);
        }
    }

    private void safeHookAll(Class<?> cls, String methodName, XC_MethodHook callback) {
        try {
            XposedBridge.hookAllMethods(cls, methodName, callback);
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": could not hook " + methodName + ": " + t);
        }
    }

    private void handleCredentialCheck(XC_MethodHook.MethodHookParam param) {
        String typedPin = extractTypedCredential(param);
        if (typedPin == null || typedPin.isEmpty()) {
            return;
        }

        XSharedPreferences prefs = new XSharedPreferences(OWN_PACKAGE, PrefsHelper.PREF_NAME);
        prefs.reload();

        if (!prefs.getBoolean(PrefsHelper.KEY_ARMED, false)) {
            return; // user turned the whole feature off in the app
        }

        if (!PrefsHelper.matches(prefs, typedPin)) {
            return; // real PIN, or any other wrong PIN - do absolutely nothing
        }

        Set<String> packages = prefs.getStringSet(PrefsHelper.KEY_APPS, null);
        if (packages == null || packages.isEmpty()) {
            return;
        }

        String mode = prefs.getString(PrefsHelper.KEY_MODE, PrefsHelper.MODE_HIDE);
        XposedBridge.log(TAG + ": duress PIN matched, acting on " + packages.size()
                + " app(s), mode=" + mode);

        for (String pkg : packages) {
            actOnPackage(pkg, mode);
        }
    }

    /**
     * Different Android versions pass the credential as a LockscreenCredential
     * object (modern) or raw bytes/String (older forks). We try the modern
     * path first and fall back gracefully.
     */
    private String extractTypedCredential(XC_MethodHook.MethodHookParam param) {
        if (param.args == null || param.args.length == 0 || param.args[0] == null) {
            return null;
        }
        Object first = param.args[0];

        // Modern (Android 11+): first arg is a LockscreenCredential
        if (first.getClass().getName().endsWith("LockscreenCredential")) {
            try {
                byte[] bytes = (byte[]) XposedHelpers.callMethod(first, "getCredential");
                return bytes == null ? null : new String(bytes);
            } catch (Throwable ignored) {
                return null;
            }
        }

        // Legacy forks: raw byte[] or String
        if (first instanceof byte[]) {
            return new String((byte[]) first);
        }
        if (first instanceof String) {
            return (String) first;
        }
        return null;
    }

    private void actOnPackage(String pkg, String mode) {
        try {
            String cmd = PrefsHelper.MODE_UNINSTALL.equals(mode)
                    ? "pm uninstall --user 0 " + pkg
                    : "pm disable-user --user 0 " + pkg;
            Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
            XposedBridge.log(TAG + ": executed [" + cmd + "]");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": failed to act on " + pkg + ": " + t);
        }
    }
}
