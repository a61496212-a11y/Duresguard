package com.you.duressguard;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.HashSet;
import java.util.Set;

/**
 * Prefs are shared between this app and the hook running inside system_server
 * via LSPosed's "New XSharedPreferences" bridge (enabled by the xposedsharedprefs
 * meta-data in the manifest + xposedminversion 93+). We never store the duress
 * PIN in plain text, only a salted SHA-256 hash, so even a world-readable prefs
 * file does not leak the PIN itself.
 */
public class PrefsHelper {

    public static final String PREF_NAME = "duress_cfg";

    public static final String KEY_SALT = "salt";
    public static final String KEY_HASH = "pin_hash";
    public static final String KEY_MODE = "mode"; // "uninstall" or "hide"
    public static final String KEY_APPS = "apps";
    public static final String KEY_ARMED = "armed"; // master on/off switch

    public static final String MODE_UNINSTALL = "uninstall";
    public static final String MODE_HIDE = "hide";

    @SuppressWarnings("deprecation")
    public static SharedPreferences get(Context context) {
        // MODE_WORLD_READABLE is only honored because LSPosed intercepts
        // ContextImpl.checkMode() for modules that declare xposedsharedprefs.
        try {
            return context.getSharedPreferences(PREF_NAME, Context.MODE_WORLD_READABLE);
        } catch (SecurityException e) {
            // Fallback for plain (non-LSPosed-hooked) runs of the app UI, e.g. in
            // the Android Studio preview or before the module is activated.
            return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        }
    }

    public static void savePin(Context context, String pin, String mode, Set<String> packages, boolean armed) {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        String saltB64 = Base64.encodeToString(salt, Base64.NO_WRAP);
        String hash = hash(pin, saltB64);

        SharedPreferences.Editor editor = get(context).edit();
        editor.putString(KEY_SALT, saltB64);
        editor.putString(KEY_HASH, hash);
        editor.putString(KEY_MODE, mode);
        editor.putStringSet(KEY_APPS, new HashSet<>(packages));
        editor.putBoolean(KEY_ARMED, armed);
        editor.apply();
    }

    public static void setArmed(Context context, boolean armed) {
        get(context).edit().putBoolean(KEY_ARMED, armed).apply();
    }

    public static boolean isArmed(Context context) {
        return get(context).getBoolean(KEY_ARMED, false);
    }

    public static boolean isPinSet(Context context) {
        return get(context).contains(KEY_HASH);
    }

    public static Set<String> getSelectedApps(Context context) {
        return get(context).getStringSet(KEY_APPS, new HashSet<>());
    }

    public static String getMode(Context context) {
        return get(context).getString(KEY_MODE, MODE_HIDE);
    }

    /** Used only from inside the hook: checks a typed PIN against the stored hash. */
    public static boolean matches(SharedPreferences prefs, String typedPin) {
        String salt = prefs.getString(KEY_SALT, null);
        String storedHash = prefs.getString(KEY_HASH, null);
        if (salt == null || storedHash == null || typedPin == null || typedPin.isEmpty()) {
            return false;
        }
        return storedHash.equals(hash(typedPin, salt));
    }

    public static String hash(String pin, String saltB64) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(Base64.decode(saltB64, Base64.NO_WRAP));
            byte[] digest = md.digest(pin.getBytes());
            return Base64.encodeToString(digest, Base64.NO_WRAP);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
