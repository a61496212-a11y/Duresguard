package com.you.duressguard;

import android.graphics.drawable.Drawable;

public class AppInfo {
    public final String packageName;
    public final String label;
    public final Drawable icon;
    public boolean selected;

    public AppInfo(String packageName, String label, Drawable icon, boolean selected) {
        this.packageName = packageName;
        this.label = label;
        this.icon = icon;
        this.selected = selected;
    }
}
