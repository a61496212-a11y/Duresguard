package com.you.duressguard;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private final List<AppInfo> apps = new ArrayList<>();
    private AppListAdapter adapter;
    private EditText pinInput;
    private RadioButton modeHide, modeUninstall;
    private Switch armedSwitch;
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.status_text);
        pinInput = findViewById(R.id.pin_input);
        modeHide = findViewById(R.id.mode_hide);
        modeUninstall = findViewById(R.id.mode_uninstall);
        armedSwitch = findViewById(R.id.armed_switch);
        RecyclerView list = findViewById(R.id.app_list);
        Button saveButton = findViewById(R.id.save_button);

        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AppListAdapter(apps);
        list.setAdapter(adapter);

        loadInstalledApps();
        restoreCurrentConfig();

        saveButton.setOnClickListener(v -> save());
    }

    private void loadInstalledApps() {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> installed = pm.getInstalledApplications(PackageManager.GET_META_DATA);

        Set<String> alreadySelected = PrefsHelper.getSelectedApps(this);

        List<AppInfo> result = new ArrayList<>();
        for (ApplicationInfo ai : installed) {
            // Skip ourselves and core system UI pieces you really don't want to touch.
            if (ai.packageName.equals(getPackageName())) continue;
            if (ai.packageName.equals("android")) continue;

            String label = pm.getApplicationLabel(ai).toString();
            Drawable icon = pm.getApplicationIcon(ai);
            boolean selected = alreadySelected.contains(ai.packageName);
            result.add(new AppInfo(ai.packageName, label, icon, selected));
        }

        Collections.sort(result, Comparator.comparing(a -> a.label.toLowerCase()));
        apps.clear();
        apps.addAll(result);
        adapter.notifyDataSetChanged();
    }

    private void restoreCurrentConfig() {
        boolean pinSet = PrefsHelper.isPinSet(this);
        statusText.setText(pinSet
                ? "Duress PIN is configured. Leave the field blank to keep it unchanged."
                : getString(R.string.status_not_set));

        armedSwitch.setChecked(PrefsHelper.isArmed(this));
        if (PrefsHelper.MODE_UNINSTALL.equals(PrefsHelper.getMode(this))) {
            modeUninstall.setChecked(true);
        } else {
            modeHide.setChecked(true);
        }
    }

    private void save() {
        String typed = pinInput.getText().toString().trim();
        Set<String> selected = new HashSet<>();
        for (AppInfo a : apps) {
            if (a.selected) selected.add(a.packageName);
        }

        if (selected.isEmpty()) {
            Toast.makeText(this, "Pick at least one app first", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean changingPin = !TextUtils.isEmpty(typed);
        if (!changingPin && !PrefsHelper.isPinSet(this)) {
            Toast.makeText(this, "Set a duress PIN first", Toast.LENGTH_SHORT).show();
            return;
        }

        String mode = modeUninstall.isChecked() ? PrefsHelper.MODE_UNINSTALL : PrefsHelper.MODE_HIDE;
        boolean armed = armedSwitch.isChecked();

        if (changingPin) {
            if (typed.length() < 4) {
                Toast.makeText(this, "Use at least 4 digits", Toast.LENGTH_SHORT).show();
                return;
            }
            PrefsHelper.savePin(this, typed, mode, selected, armed);
            pinInput.setText("");
        } else {
            // Keep the existing PIN hash, just update apps/mode/armed.
            PrefsHelper.get(this).edit()
                    .putString(PrefsHelper.KEY_MODE, mode)
                    .putStringSet(PrefsHelper.KEY_APPS, selected)
                    .putBoolean(PrefsHelper.KEY_ARMED, armed)
                    .apply();
        }

        Toast.makeText(this, "Saved. Make sure the module is enabled for " +
                "\"System Framework\" in LSPosed and reboot once after first setup.",
                Toast.LENGTH_LONG).show();
        restoreCurrentConfig();
    }
}
