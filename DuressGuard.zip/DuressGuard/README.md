# DuressGuard — LSPosed duress-PIN module

Type your normal unlock PIN → unlocks normally, nothing happens.
Type any other wrong PIN → counts as a failed attempt, nothing happens.
Type your chosen **duress PIN** → the apps you picked get hidden or uninstalled, silently.

## Build it

1. Open this folder in **Android Studio** (Giraffe or newer).
2. Let Gradle sync. It pulls the classic Xposed API jar from `https://api.xposed.info/`
   (declared in `settings.gradle`) — no account/key needed.
3. Build → Build APK, or `./gradlew assembleDebug`.
4. Install the APK on your Lunaris AOSP 16 device, normally (it's a regular app).

## Activate it

1. Open **LSPosed Manager** → Modules → enable **DuressGuard**.
2. Tap it, set its scope to include **System Framework** (`android` / `system_server`).
3. **Reboot.** The hook only attaches after a reboot (and only works after your
   *first* unlock following that reboot — before first unlock the credential
   check runs in a different code path the hook can't see).

## Configure

1. Open the DuressGuard app.
2. Pick the apps you want tied to the duress PIN.
3. Choose **Hide** (reversible — `pm disable-user`, apps vanish from the
   launcher but all data stays) or **Uninstall** (removes the app and its data;
   not a secure wipe, just a normal uninstall).
4. Type your duress PIN (≥4 digits) — pick something you will never mistype as
   your real PIN. Don't make it a substring/prefix of your real PIN.
5. Flip the **armed** switch on.
6. Save.

## How it actually works

The hook sits in `LockSettingsService.checkCredential/verifyCredential` inside
`system_server`. It reads what you typed, compares a SHA-256 hash of it
against the hash you set (the PIN itself is never stored in plain text), and
only if that matches does it act — then lets the normal check continue, so the
lock screen still just reports a wrong PIN either way.

## Things to know before you rely on this

- **Reboot/first-unlock gap**: right after a reboot, before you've entered your
  real PIN once, the hook isn't active yet on that boot.
- **"Uninstall" isn't forensic**: it's a normal `pm uninstall`, recoverable data
  can remain in backups/cloud, and it won't remove apps that are protected
  system apps on your ROM (those will just fail silently — check `adb logcat -s DuressGuard`
  if something doesn't disappear).
- **SELinux/ROM variance**: Lunaris is AOSP-based, so this should work as-is,
  but if a future build locks down `system_server`'s ability to `exec()` a
  shell, the uninstall/hide step would silently fail. Test it once on a
  throwaway app before trusting it.
- **This changes what your phone does under duress.** Make sure you're
  comfortable with the apps you pick actually disappearing, and that losing
  them doesn't itself tip someone off in a way you don't want.
